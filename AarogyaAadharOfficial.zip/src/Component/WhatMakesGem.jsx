import React from 'react'

const WhatMakesGem = () => {
    return (
        <>
            <div className='text-2xl text-center mb-3'>
            What Makes GEM Subscription Different?
            </div>
            <hr className='divider mb-8'/>
        </>
    )
}

export default WhatMakesGem
