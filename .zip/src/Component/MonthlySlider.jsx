import React from 'react'
import "../css/style.css"
const MonthlySlider = () => {
    return (
        <div className="relative flex w-full h-screen overflow-hidden">
            <div className="relative w-[60%] h-[90%]">
                <img
                    src="https://d2aq6dqxahe4ka.cloudfront.net/themes/neumorphism/images/landing_pages/v2/Recurring-Banner-web.webp"
                    alt="Slider"
                    className="w-full h-full object-cover"
                />
            </div>

            <div className="absolute top-0 right-0 w-[70%] h-[90%] flex items-start p-4"
                style={{
                    background: 'linear-gradient(269deg, #0033a0, #0066cc 64%, rgba(0,102,204,0.73) 75%, rgba(0,153,255,0))'
                }}>
                <div className="ml-[25%] flex flex-col p-4">
                    <span className="text-white text-5xl font-bold mb-2">GEM : <i>Give Every Month</i></span>
                    <span className="text-white text-4xl  mb-2"><i>Subscribe Now to Save Patients, Monthly.</i></span>
                    <div class="relative flex items-center w-48 mx-auto mt-10">
                        <div class="absolute -top-12 left-0 p-2 bg-gray-200 rounded shadow-md">
                            Comment
                        </div>
                        <div class="absolute top-1/2 left-0 w-full border-t-2 border-dotted border-gray-600 -z-10"></div>
                        <div class="flex flex-col items-center mx-2">
                            <div class="w-4 h-4 bg-black rounded-full"></div>
                            <div class="text-sm mt-2">Label 1</div>
                        </div>
                        <div class="flex flex-col items-center mx-2">
                            <div class="w-4 h-4 bg-black rounded-full"></div>
                            <div class="text-sm mt-2">Label 2</div>
                        </div>
                        <div class="flex flex-col items-center mx-2">
                            <div class="w-4 h-4 bg-black rounded-full"></div>
                            <div class="text-sm mt-2">Label 3</div>
                        </div>
                        <div class="flex flex-col items-center mx-2">
                            <div class="w-4 h-4 bg-black rounded-full"></div>
                            <div class="text-sm mt-2">Label 4</div>
                        </div>
                    </div>

                    <button class="flex items-center bg-white text-blue-600 font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-slate-200 transition-colors w-[220px]">
                        <i class="fas fa-heart heart-icon mr-2 text-lg"></i>
                        BE A GEM DONOR
                    </button>
                </div>
            </div>
        </div>
    )
}

export default MonthlySlider
